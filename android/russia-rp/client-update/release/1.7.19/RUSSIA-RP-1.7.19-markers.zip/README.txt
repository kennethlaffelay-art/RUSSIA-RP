RUSSIA RP 1.7.19
radar/ — 20 значков 64×64. pickups/ — варианты 256×256 на прозрачном фоне.
В markers.json поле texture задаёт активную текстуру в клиенте. Значение null означает заготовку.
На сервере значки автосалона и отеля привязаны к карте и табличкам у входа.
Источники пиктограмм: https://github.com/mapbox/maki
Основа шрифта: https://github.com/google/fonts/tree/main/ofl/robotocondensed
